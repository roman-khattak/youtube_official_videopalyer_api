package com.example.flutter_youtube_official_videopalyer_api

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
